SYNTHETIC EuRoC-FORMAT SAMPLE DATASET
======================================
This is a small procedurally-generated dataset built ONLY to demo/test the
EuRoC pipeline path end-to-end -- it is NOT a real MAV recording, and the
"IMU" and "ground truth" here were both derived from the same underlying
synthetic trajectory (so they are consistent with each other by construction,
not independently measured).

It follows the exact EuRoC MAV folder/file format (mav0/cam0, mav0/imu0,
mav0/state_groundtruth_estimate0, sensor.yaml), so any REAL EuRoC sequence
(e.g. MH_01_easy, V1_01_easy from https://projects.asl.ethz.ch/datasets/)
can be dropped in with the same structure and will work identically.
